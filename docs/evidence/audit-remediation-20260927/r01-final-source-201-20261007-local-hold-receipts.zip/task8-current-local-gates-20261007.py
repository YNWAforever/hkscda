import pathlib,subprocess,sys,os,json,hashlib,datetime,time,shutil,re
sys.stdout.reconfigure(encoding='utf-8')
w=pathlib.Path.cwd().resolve();ctl=w/'.superpowers/sdd/sequential-merge-20261006'
head='ae0abf38443a93be6a9d7a34fbc8e24ec4fd60de';tree='e5e5d5abe4da492b14b9a00fef6882fee4ef313c'
def git(*args):
 r=subprocess.run(['git',*args],capture_output=True,cwd=w)
 assert r.returncode==0,(args,r.returncode)
 return r.stdout
assert git('rev-parse','HEAD').decode().strip()==head
assert git('rev-parse','HEAD^{tree}').decode().strip()==tree
assert not git('status','--porcelain','--untracked-files=no').strip()
out=ctl/('task8-current-local-gates-'+str(time.time_ns()));out.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,obj):(out/name).write_bytes((json.dumps(obj,indent=2)+'\n').encode())
oskeys={'PATH','SYSTEMROOT','WINDIR','TEMP','TMP','LOCALAPPDATA','USERPROFILE','APPDATA','HOMEDRIVE','HOMEPATH','COMSPEC','PATHEXT','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE','PROGRAMFILES','PROGRAMFILES(X86)','PROGRAMDATA','OS'}
env={k:v for k,v in os.environ.items() if k.upper() in oskeys}
bun='C:/Users/laich/.bun/bin/bun.exe';env['PATH']=str(pathlib.Path(bun).parent)+';'+env.get('PATH','')
env.update({k:'http://127.0.0.1:59999' for k in ['VITE_SUPABASE_URL','SUPABASE_URL','SUPABASE_LOCAL_URL','LOCAL_SUPABASE_URL']})
env.update({k:'ci-placeholder-anon-key' for k in ['VITE_SUPABASE_ANON_KEY','SUPABASE_ANON_KEY','LOCAL_SUPABASE_ANON_KEY']})
env.update({k:'ci-placeholder-service-role-key' for k in ['SUPABASE_SERVICE_ROLE_KEY','LOCAL_SUPABASE_SERVICE_ROLE_KEY']})
assert not any(k.endswith('TEST_DATABASE_URL') or k.endswith('ALLOW_LOCAL_FIXTURES') or k in ('CI','GITHUB_ACTIONS') for k in env)
result={'head':head,'tree':tree,'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(w),'freeBytesBefore':shutil.disk_usage(w).free,'floorBytes':2147483648,'retainedOSKeys':sorted(k for k in env if k.upper() in oskeys),'placeholders':{k:v for k,v in env.items() if k.upper() not in oskeys},'CI_GITHUB_ACTIONS_PROVIDER_FIXTURE_OPTINS':'OMITTED','commands':[],'preservation':{},'sourceOnly':True,'productionApplied':False,'nativeTask8Nineteen':'NOT_RUN: fresh CI remains mandatory'}
paths=git('ls-files','.github','src','scripts','supabase','package.json','bun.lock','tsconfig.json','eslint.config.js','vite.config.ts').decode().splitlines()
frozen={p:sha((w/p).read_bytes()) for p in paths}
save('frozen-inputs.json',frozen);result['frozenSourceCount']=len(frozen)
def run(name,argv,timeout=600):
 stdout=out/(name+'.stdout');stderr=out/(name+'.stderr');start=time.monotonic()
 with stdout.open('xb') as so,stderr.open('xb') as se:
  p=subprocess.Popen(argv,cwd=w,env=env,stdout=so,stderr=se);code=p.wait(timeout=timeout)
 r={'name':name,'argv':argv,'pid':p.pid,'exit':code,'elapsedSeconds':round(time.monotonic()-start,2),'streams':[{'file':x.name,'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in [stdout,stderr]]}
 result['commands'].append(r);save('receipt.json',result);print(json.dumps(r),flush=True)
 assert code==0,(name,code)
 return stdout.read_text(encoding='utf-8')
def probe(name,port,db,expected):
 script='import {localSourceState} from "./supabase/rls-tests/helpers/productionSchemaClone";console.log(await localSourceState("postgresql://postgres:postgres@127.0.0.1:'+str(port)+'/'+db+'"));'
 value=run(name,[bun,'--no-env-file','-e',script],120).strip()
 assert re.fullmatch('[a-f0-9]{64}',value),(name,'unknown snapshot format')
 result['preservation'][name]=value;save('receipt.json',result)
 assert value==expected,(name,'complete raw source hash differs',value,expected)
 return value
try:
 assert result['freeBytesBefore']>=result['floorBytes'],'fixed free-space floor'
 runtime_env=[p for p in ['.env','.env.local','.env.development','.env.development.local','.env.test','.env.test.local','.env.production','.env.production.local'] if (w/p).exists()]
 assert not runtime_env,('runtime dotenv present',runtime_env)
 run('bun-version',[bun,'--version']);run('node-version',['C:/Program Files/nodejs/node.exe','--version']);run('python-version',[sys.executable,'--version'])
 probe('modern-before',57322,'postgres','f5b51515bcf790adf7928168478ef94eabbf7331a84420fe744ab7f04e75028b')
 probe('template-before',52322,'audit_pr135_20260929','c653c8e55cd609b04ca58f3c288549e57da84afe92fe559882c423139a46edb6')
 for name,argv in [('typecheck',[bun,'--no-env-file','run','typecheck']),('tests',[bun,'--no-env-file','test','--isolate','--timeout','30000']),('lint',[bun,'--no-env-file','run','lint']),('build',[bun,'--no-env-file','run','build'])]:
  assert shutil.disk_usage(w).free>=result['floorBytes'],'fixed free-space floor before '+name
  run(name,argv)
  if name=='tests':
   content=(out/'tests.stdout').read_text(encoding='utf-8',errors='replace')+(out/'tests.stderr').read_text(encoding='utf-8',errors='replace')
   result['unitSummary']=re.findall(r'^\s*\d+ (?:pass|fail|skip|expect\(\) calls)\s*$',content,re.M)
  if name=='lint':
   content=(out/'lint.stdout').read_text(encoding='utf-8',errors='replace')+(out/'lint.stderr').read_text(encoding='utf-8',errors='replace')
   result['lintSummary']=re.findall(r'^.*\d+ problems.*$',content,re.M)
  save('receipt.json',result)
 probe('modern-after',57322,'postgres',result['preservation']['modern-before'])
 probe('template-after',52322,'audit_pr135_20260929',result['preservation']['template-before'])
 assert git('rev-parse','HEAD').decode().strip()==head
 assert not git('status','--porcelain','--untracked-files=no').strip()
 diffs=[p for p,h in frozen.items() if sha((w/p).read_bytes())!=h]
 result['sourceRawDrift']=diffs;assert not diffs,('source raw drift',diffs)
 result['modernPreserved']=True;result['templatePreserved']=True;result['frozenInputsPreserved']=True;result['allFourGates']=True
except Exception as e:
 result['errorType']=type(e).__name__;result['error']=str(e);result['allFourGates']=False
finally:
 result['completedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['freeBytesAfter']=shutil.disk_usage(w).free;save('receipt.json',result)
 pointer=ctl/'task8-current-local-gates-pointer-20261007.json';assert not pointer.exists()
 pointer.write_bytes((json.dumps({'folder':out.relative_to(w).as_posix(),'receipt':(out/'receipt.json').relative_to(w).as_posix(),'head':head,'tree':tree,'allFourGates':result['allFourGates'],'receiptSHA256':sha((out/'receipt.json').read_bytes())},indent=2)+'\n').encode())
 print(json.dumps({'folder':str(out),'head':head,'allFourGates':result['allFourGates'],'error':result.get('error'),'unitSummary':result.get('unitSummary')}),flush=True)
sys.exit(0 if result.get('allFourGates') else 1)

