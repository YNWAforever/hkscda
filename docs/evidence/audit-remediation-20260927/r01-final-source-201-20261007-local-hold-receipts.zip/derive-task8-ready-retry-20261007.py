import pathlib,hashlib,ast,json,sys
sys.stdout.reconfigure(encoding='utf-8')
d=pathlib.Path('.superpowers/sdd/sequential-merge-20261006')
original=d/'task8-current-local-gates-20261007.py';new=d/'task8-current-local-gates-ready-20261007.py'
raw=original.read_bytes();a=b'task8-current-local-gates-pointer-20261007.json';b=b'task8-current-local-gates-pointer-ready-20261007.json'
assert raw.count(a)==1 and raw.count(b'\ntry:\n')==1 and not new.exists()
injected=b'\nresult["retryOf"]=json.loads((ctl/"task8-current-local-gates-pointer-20261007.json").read_bytes())\nresult["retryReason"]="External readiness transition: failed ConnectionClosed/portFalse, then Docker containers recently up and portTrue; no root restart or mutation."\n'
updated=raw.replace(a,b).replace(b'\ntry:\n',injected+b'\ntry:\n')
assert updated.replace(b,a).replace(injected,b'')==raw
ast.parse(updated.decode('utf-8'));new.write_bytes(updated)
print(json.dumps({'originalSHA256':hashlib.sha256(raw).hexdigest(),'retrySHA256':hashlib.sha256(updated).hexdigest(),'onlyMetadataPointerAndRetryProvenanceChanged':True,'commandsEnvironmentTimeoutSnapshotContractsUnchanged':True}))

