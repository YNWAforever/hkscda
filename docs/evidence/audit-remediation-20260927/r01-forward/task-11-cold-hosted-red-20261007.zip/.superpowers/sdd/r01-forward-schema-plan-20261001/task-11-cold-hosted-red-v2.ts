import { mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { captureProductionSchema, createProductionClone, assertSafeFixtureTables, snapshot, localSourceState, hash } from "./task-11-cold-hosted-transport-adapter";
import { functionsQuery, authQuery, nativeQuery, indexDetailsQuery, shapesQuery, fixtureScope, dependencies, names } from "../../../docs/evidence/audit-remediation-20260927/r01-forward/task-11-profile";
import { prerequisiteProjection } from "../../../docs/evidence/audit-remediation-20260927/r01-forward/task-11-native-profile";
const root=process.cwd(),out=resolve(".superpowers/sdd/r01-forward-schema-plan-20261001/task-11-cold-hosted-red-v2-"+Date.now());await mkdir(out,{recursive:true});
const r: Record<string,unknown>={out,productionApplied:false,mode:"owned-hosted-after-approved90e-fresh6c4",approvedTask1ControlClampApplied:true};let c:Awaited<ReturnType<typeof createProductionClone>>|undefined;
const modern="postgresql://postgres:postgres@127.0.0.1:57322/postgres",beforeShared=await localSourceState(modern);
try{
 const captured=await captureProductionSchema();await writeFile(resolve(out,"hosted-schema.source"),captured.schema);await writeFile(resolve(out,"hosted-catalog.json"),JSON.stringify(captured.catalog,null,2)+"\n");r.hostedSchemaOnly=true;r.productionCatalogStableDuringCapture=true; c=await createProductionClone(captured);r.clone=c.name;r.runtime=await c.sql`select version(),current_user,current_database()`;
 await assertSafeFixtureTables(c.sql,fixtureScope);r.fullScannerPassed=true;
 for(const [f,h]of dependencies){const b=await readFile(resolve(root,"supabase/migrations",f));if(createHash("sha256").update(b).digest("hex")!==h)throw Error("Dependency differs "+f);await c.sql.begin(async tx=>{await tx`set local role postgres`;await tx.unsafe(b.toString())})}
 const metadata=async()=>({catalog:await snapshot(c!.sql),functions:await c!.sql.unsafe(functionsQuery),auth:(await c!.sql.unsafe(authQuery))[0].value,native:(await c!.sql.unsafe(nativeQuery))[0].value,indexes:(await c!.sql.unsafe(indexDetailsQuery))[0].value,shapes:(await c!.sql.unsafe(shapesQuery))[0].value});
 const original=await metadata();await writeFile(resolve(out,"before-clamp.json"),JSON.stringify(original,null,2)+"\n");
 const clamp=await readFile(resolve(root,"supabase/migrations/20261001101333_r01_payment_idempotency_forward.sql"));await writeFile(resolve(out,"clamp.source"),clamp);r.clampSha256=createHash("sha256").update(clamp).digest("hex");await c.sql.begin(async tx=>{await tx`set local role postgres`;await tx.unsafe(clamp.toString())});
 const before=await metadata();await writeFile(resolve(out,"after-clamp.json"),JSON.stringify(before,null,2)+"\n");
 const pair={catalog:prerequisiteProjection(before.catalog),helpers:before.functions.filter(f=>!(f.schema==="public"&&names.includes(f.name)))};
 await writeFile(resolve(out,"observed-pair.json"),JSON.stringify(pair,null,2)+"\n");
 const candidate=await readFile(resolve(root,"supabase/migrations/20261002170945_r01_finance_callback_forward.sql"));await writeFile(resolve(out,"candidate.source"),candidate);r.candidateSha256=createHash("sha256").update(candidate).digest("hex");
 let failure:unknown;try{await c.sql.begin(async tx=>{await tx`set local role postgres`;await tx.unsafe(candidate.toString())})}catch(e){failure=e}
 r.errorObserved=String(failure);r.sqlstate=(failure as {errno?:string}|undefined)?.errno;r.rollbackPreserved=hash(before)===hash(await metadata());
 if(r.sqlstate!=="55000"||!r.rollbackPreserved)throw Error("Missing actual RED or rollback");r.eligible=true;
}catch(e){r.error=String(e);r.eligible=false}finally{if(c){await c.close();r.normalDrop=true;r.templatePreserved=c.templatePreserved}r.modernPreserved=beforeShared===await localSourceState(modern);await writeFile(resolve(out,"receipt.json"),JSON.stringify(r,null,2)+"\n");console.log(JSON.stringify(r));if(r.eligible!==true||r.modernPreserved!==true)process.exitCode=1}
