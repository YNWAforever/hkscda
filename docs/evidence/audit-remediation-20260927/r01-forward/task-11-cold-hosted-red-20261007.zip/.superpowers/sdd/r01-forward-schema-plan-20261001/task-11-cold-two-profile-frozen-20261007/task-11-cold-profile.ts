/** Exact measured Task1 control ACL composition; historical proof stays immutable. */
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import evidence from "./task-11-cold-prerequisites.json";

const prefix = "docs/evidence/audit-remediation-20260927/r01-forward/";
const rawPin = "7338a1d3e2f5c98ba836210848d3372d7e90336cf80e8229f1a284f29cef8679";
const objectPin = "7f72c893b874028b8fe81e1877d218ae426df52abbf833cc2fd1cba57abc8e97";
const sha = (bytes: Uint8Array | string) => createHash("sha256").update(bytes).digest("hex");

export function assertColdEvidence(value: unknown): typeof evidence {
  // Bind the complete vectors and actual RED/cleanup provenance together.
  if (sha(JSON.stringify(value)) !== objectPin)
    throw new Error("Task11 observed control ACL evidence differs");
  return value as typeof evidence;
}

export async function verifyColdEvidence(root: string) {
  const paths = [prefix + "task-11-cold-prerequisites.json", evidence.clampSource,
    prefix + evidence.archive, prefix + evidence.manifest];
  const pins = [rawPin, evidence.clampSha256, evidence.archiveSha256, evidence.manifestSha256];
  for (const [i, path] of paths.entries())
    if (sha(await readFile(resolve(root, path))) !== pins[i])
      throw new Error("Task11 observed control ACL source/archive binding differs: " + path);
  return { evidence: assertColdEvidence(evidence), paths };
}

/** Each additional catalog selects ONLY its observed helper vector. */
export function withObservedPairs(
  historical: { catalog: string; helpers: string },
  pairs: { catalog: string; helpers: string }[],
) {
  if (!pairs.length) throw new Error("Observed Task11 pairs required");
  const selection = pairs.map((p, i) => `when v_before=${p.catalog} then ${i}`).join(" ");
  const helpers = pairs.map((p, i) => `when ${i} then ${p.helpers}`).join(" ");
  return {
    catalog: ` v_observed:=case ${selection} else null end;\n if v_observed is null then\n${historical.catalog} else v_native:=false;end if;\n`,
    helpers: ` if v_observed is null then\n${historical.helpers} elsif v_actual<>(case v_observed ${helpers} end) then raise exception 'R01 finance complete helper tuples differ' using errcode='55000';end if;\n`,
  };
}
