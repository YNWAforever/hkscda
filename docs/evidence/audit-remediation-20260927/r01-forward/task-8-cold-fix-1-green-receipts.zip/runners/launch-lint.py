from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path(r"C:\Users\laich\Documents\HKCSDA\HKCSDA\hkscda\.worktrees\audit-sequential-merge-20261006")
c=r/".superpowers/sdd/sequential-merge-20261006"
p=c/"task8-cold-native-201-20261007"
out=c/("task8-cold-201-capture-"+str(time.time_ns()))
keys=["SystemRoot","WINDIR","SystemDrive","COMSPEC","PATH","PATHEXT","TEMP","TMP","USERPROFILE","APPDATA","LOCALAPPDATA","PROGRAMFILES","PROGRAMFILES(X86)","PROGRAMDATA","HOMEDRIVE","HOMEPATH","NUMBER_OF_PROCESSORS","PROCESSOR_ARCHITECTURE"]
env={k:v for k,v in os.environ.items() if k.upper() in {x.upper() for x in keys}}
argv=[r"C:/Users/laich/.bun/bin/bun.exe","--no-env-file","node_modules/eslint/bin/eslint.js","docs/evidence/audit-remediation-20260927/r01-forward/task-8-generate.ts","docs/evidence/audit-remediation-20260927/r01-forward/task-8-cold-fix-1-profile.ts","docs/evidence/audit-remediation-20260927/r01-forward/task-8-cold-fix-1-profile.test.ts"]
t=time.time(); result=subprocess.run(argv,cwd=r,env=env,capture_output=True)
receipt={"argv":argv,"nativeExit":result.returncode,"elapsedSeconds":time.time()-t,"out":str(out),"cleanOSEnvironment":sorted(env),"stdoutSha256":hashlib.sha256(result.stdout).hexdigest(),"stderrSha256":hashlib.sha256(result.stderr).hexdigest()}
for key,data in [("stdout",result.stdout),("stderr",result.stderr)]: (c/("task8-cold-fix-1-lint-20261007."+key)).write_bytes(data)
(c/"task8-cold-fix-1-lint-pointer-20261007.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf8")
print(json.dumps(receipt)); print(result.stdout.decode("utf8",errors="replace")); print(result.stderr.decode("utf8",errors="replace")); raise SystemExit(result.returncode)
