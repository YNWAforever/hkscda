/** Diagnostic only. Never import a shared-state capture/rehearsal runner. */
import { SQL } from "bun";
import { createHash } from "node:crypto";
import { readFile, writeFile, mkdir, realpath, readdir, lstat } from "node:fs/promises";
import { resolve, relative, dirname, sep } from "node:path";
import { isDeepStrictEqual } from "node:util";
import { catalogQuery, assertSafeFixtureTables } from "../../../../supabase/rls-tests/helpers/productionSchemaClone";
import { fixtureScope, functionsQuery, targetQuery, authQuery, nativeQuery, indexDetailsQuery, shapeQuery } from "../../../../docs/evidence/audit-remediation-20260927/r01-forward/task-8-profile";

const root = resolve(import.meta.dir, "../../../..");
const controller = resolve(root, ".superpowers/sdd/sequential-merge-20261006");
const projectId = "hkscda-task8-cold-201-20261007";
const expectedUrl = "postgresql://postgres:postgres@127.0.0.1:61322/postgres";
const task8 = "supabase/migrations/20261006163243_r01_volunteer_atomic_forward.sql";
const sha = (bytes: Uint8Array | string) => createHash("sha256").update(bytes).digest("hex");
const json = (value: unknown) => JSON.stringify(value, (_, v) => typeof v === "bigint" ? v.toString() : v, 2) + "\n";
function assert(value: unknown, message: string): asserts value { if (!value) throw Error(message); }
const within = (base: string, path: string) => { const r = relative(base, path); return !!r && !r.startsWith(".." + sep) && r !== ".." && !resolve(path).startsWith("\\\\"); };
const [ownershipArg, readyArg, outArg] = process.argv.slice(2);
assert(process.argv.slice(2).length === 3 && ownershipArg && readyArg && outArg, "Ownership/readiness receipts and new output directory required");
const ownershipPath = resolve(ownershipArg), readyPath = resolve(readyArg), out = resolve(outArg);
assert(within(controller, ownershipPath) && within(controller, readyPath) && within(controller, out), "Only controller-owned diagnostic paths allowed");
assert(/^task8-cold-201-capture-[0-9]+$/.test(relative(controller, out)), "New unique capture directory required");
assert(process.env.CI !== "true" && process.env.GITHUB_ACTIONS !== "true", "This local diagnostic must not pretend to be native CI");
const ownBytes = await readFile(ownershipPath), originalOwn = JSON.parse(ownBytes.toString("utf8"));
const readyBytes = await readFile(readyPath), ready = JSON.parse(readyBytes.toString("utf8"));
assert(ready.receiptVersion === 1 && ready.receiptType === "task8-cold-201-owned-ready" && ready.ownershipSha256 === sha(ownBytes) && ready.healthConfirmed === true, "Exact root readiness/ownership binding required");
assert(originalOwn.projectId === projectId && originalOwn.url === expectedUrl && originalOwn.freshEmptyOnly === true && originalOwn.original553523573Untouched === true && originalOwn.productionApplied === false && originalOwn.seedEnabled === false && originalOwn.postgresVersion === "17.11.0.004" && originalOwn.gotrueRequired === "v2.197.0" && originalOwn.cliRequired === "2.120.0", "Ownership boundary/image/version differs");
assert(originalOwn.predecessorHead === "7eba7c4bbfba61267415276f4d53a873cf7c4520" && originalOwn.predecessorTree === "d9741dc33d1e892873f22db01522bac9b405968b", "Original creation-snapshot source binding differs");
assert(Array.isArray(originalOwn.predecessorMigrations) && originalOwn.predecessorMigrations.length === 186 && isDeepStrictEqual(originalOwn.ports,[61320,61321,61322,61323,61324,61325,61326,61327,61328,61329]), "Complete 186 predecessor/port inventory required");
const project = resolve(originalOwn.fixtureRoot), config = resolve(project, "supabase/config.toml");
assert(dirname(ownershipPath) === project && dirname(readyPath) === project, "Ownership/readiness must reside in the exact owned project");
const startupPath = resolve(ready.startupReceiptPath);
assert(within(project,startupPath), "Startup receipt must reside in owned project");
const startupBytes = await readFile(startupPath), startup = JSON.parse(startupBytes.toString("utf8"));
assert(sha(startupBytes) === ready.startupReceiptSha256 && startup.nativeExit === 0 && startup.projectId === projectId && startup.productionApplied === false, "Native startup readiness receipt differs");
const own = { ...originalOwn, authority:"root-owned-isolated-diagnostic", ownerNonce:sha(ownBytes).slice(0,32), projectDirectory:project, configPath:config, configSha256:originalOwn.configRawSHA256, predecessors:originalOwn.predecessorMigrations.map((p:{file:string;rawSHA256:string;rawBytes:number;lfSHA256:string})=>({...p,path:"supabase/migrations/"+p.file,sha256:p.rawSHA256})), containers:ready.containers };
assert(within(controller, project) && await realpath(project) === project && await realpath(config) === config, "Project/config must be real controller-owned paths");
assert(own.configPath === config && !(await lstat(project)).isSymbolicLink(), "Exact owned config and ordinary project directory required");
const configBytes = await readFile(config), configText = configBytes.toString("utf8");
assert(sha(configBytes) === own.configSha256 && /^project_id\s*=\s*"hkscda-task8-cold-201-20261007"\s*$/m.test(configText), "Owned config/project pin differs");
const section = (name: string) => configText.match(new RegExp("^\\[" + name.replaceAll(".", "\\.") + "\\]\\r?\\n([\\s\\S]*?)(?=^\\[|$(?![\\s\\S]))", "m"))?.[1] ?? "";
assert(/^port\s*=\s*61322\s*$/m.test(section("db")) && /^major_version\s*=\s*17\s*$/m.test(section("db")), "Exact new database port/major required");
assert(/^port\s*=\s*61321\s*$/m.test(section("api")) && /^enabled\s*=\s*false\s*$/m.test(section("db.seed")), "Exact new API port and disabled seed required");
const walk = async (path: string): Promise<void> => {
  for (const entry of await readdir(path, { withFileTypes: true })) {
    const child = resolve(path, entry.name);
    assert(!entry.isSymbolicLink(), "Owned project symlink refused");
    assert(entry.name !== ".env" && !entry.name.startsWith(".env.") && entry.name !== "seed.sql" && entry.name !== "project-ref" && entry.name !== "linked-project", "Env/link/seed file refused");
    if (entry.isDirectory()) await walk(child);
  }
};
await walk(project);
const pgVersionPath = resolve(project, "supabase/.temp/postgres-version");
const pgVersion = await readFile(pgVersionPath);
assert(pgVersion.toString("utf8").trim() === "17.11.0.004", "Exact observed-CI PostgreSQL image pin required");
const migrations = (await readdir(resolve(root, "supabase/migrations"))).filter(p => p.endsWith(".sql")).sort();
assert(migrations.length === 187 && migrations.at(-1) === task8.split("/").at(-1), "Frozen source migration inventory differs");
const expectedPredecessors = migrations.slice(0, -1).map(name => "supabase/migrations/" + name);
assert(isDeepStrictEqual(own.predecessors.map((p: {path: string}) => p.path), expectedPredecessors), "Ordered predecessor source list differs");
const copied = (await readdir(resolve(project, "supabase/migrations"))).filter(p => p.endsWith(".sql")).sort();
assert(isDeepStrictEqual(copied, migrations.slice(0, -1)), "Only 186 predecessors may exist in new bootstrap project");
const paths = [...expectedPredecessors, task8,
  "supabase/rls-tests/helpers/productionSchemaClone.ts",
  "docs/evidence/audit-remediation-20260927/r01-forward/task-8-profile.ts",
  "docs/evidence/audit-remediation-20260927/r01-forward/task-8-generate.ts",
  "src/lib/volunteers/atomicForward.database.test.ts",
  "src/lib/volunteers/atomicForwardFixtureGuard.ts",
  "docs/evidence/audit-remediation-20260927/r01-forward/task-8-cold-fix-1-profile.ts",
  "docs/evidence/audit-remediation-20260927/r01-forward/task-8-cold-fix-1-profile.test.ts",
  "docs/evidence/audit-remediation-20260927/r01-forward/task-8-cold-fix-1-binding.json",
  "docs/evidence/audit-remediation-20260927/r01-forward/task-8-cold-fix-1-raw-receipts.zip"];
const frozen = new Map<string, Uint8Array>();
for (const path of paths) frozen.set(path, await readFile(resolve(root, path)));
for (const p of own.predecessors) {
  const b = frozen.get(p.path)!;
  assert(sha(b) === p.sha256 && sha(Buffer.from(b).toString("utf8").replaceAll("\r\n","\n")) === p.lfSHA256 && b.byteLength === p.rawBytes && Buffer.from(b).equals(await readFile(resolve(project, p.path))), "Original/copied predecessor source pin differs: " + p.path);
}
// Bind all executable inputs to the immutable creation snapshot without editing Git.
const sourceGitProofs: Record<string,unknown> = {};
for (const path of paths.slice(186,192).filter(p => ![task8,"docs/evidence/audit-remediation-20260927/r01-forward/task-8-profile.ts","docs/evidence/audit-remediation-20260927/r01-forward/task-8-generate.ts"].includes(p))) {
  const proc=Bun.spawn(["git","cat-file","blob",own.predecessorHead+":"+path],{cwd:root,stdout:"pipe",stderr:"pipe"});
  const [blob,stderr,nativeExit]=await Promise.all([new Response(proc.stdout).arrayBuffer(),new Response(proc.stderr).text(),proc.exited]);
  assert(nativeExit===0 && stderr==="" && sha(new Uint8Array(blob))===sha(Buffer.from(frozen.get(path)!).toString("utf8").replaceAll("\r\n","\n")),"Current executable source differs from ownership Git snapshot: "+path);
  sourceGitProofs[path]={argv:["git","cat-file","blob",own.predecessorHead+":"+path],nativeExit,gitContentSha256:sha(new Uint8Array(blob)),currentRawSha256:sha(frozen.get(path)!)};
}
const versionReceiptPath=resolve(project,"version-receipt.json"),versionBytes=await readFile(versionReceiptPath),version=JSON.parse(versionBytes.toString("utf8"));
const checkArgv=(argv:string[],operation:string)=>Array.isArray(argv)&&argv[1]==="--no-env-file"&&argv[2]==="x"&&argv[3]==="supabase@2.120.0"&&argv.includes("--agent=no")&&argv.includes("--workdir")&&argv[argv.indexOf("--workdir")+1]===project&&argv.includes(operation);
assert(version.nativeExit===0&&version.projectId===projectId&&version.productionApplied===false&&checkArgv(version.argv,"--version")&&checkArgv(startup.argv,"start"),"Exact CLI version/start argv differs");
const prerequisiteStreams:Record<string,Uint8Array>={};
for(const [label,receipt]of [["version",version],["startup",startup]] as const){
  assert(Array.isArray(receipt.streams)&&receipt.streams.length===2,"Native CLI stream cardinality differs");
  for(const stream of receipt.streams){const path=resolve(project,stream.file);assert(within(project,path),"Native CLI stream path refused");const bytes=await readFile(path);assert(sha(bytes)===stream.sha256&&bytes.byteLength===stream.bytes,"Native CLI stream pin differs");prerequisiteStreams[label+"-"+stream.file]=bytes;}
}
const versionStdout=version.streams.find((s:{file:string})=>s.file.endsWith(".stdout"));
assert(versionStdout&&Buffer.from(prerequisiteStreams["version-"+versionStdout.file]).toString("utf8").trim()==="2.120.0","CLI version raw output differs");
const templateReceiptPath=resolve(project,"referenced-template-inputs.json"),templateBytes=await readFile(templateReceiptPath),templateReceipt=JSON.parse(templateBytes.toString("utf8"));
assert(templateReceipt.nativeExit===0&&templateReceipt.members?.length===1&&templateReceipt.members[0].file==="supabase/templates/login-otp.html","Exact config template dependency proof required");
const templatePin=templateReceipt.members[0],templateFileBytes=await readFile(resolve(project,templatePin.file));
assert(sha(templateFileBytes)===templatePin.rawSHA256&&templateFileBytes.byteLength===templatePin.bytes&&templateFileBytes.equals(await readFile(resolve(root,templatePin.file))),"Copied config template input differs");

// All checks above inspect files only. Docker identity checks also precede connection.
await mkdir(out); // Existing output is refused; no original file can be overwritten.
const files: Record<string, {sha256: string; bytes: number}> = {};
const save = async (name: string, bytes: string | Uint8Array) => { await writeFile(resolve(out, name), bytes, { flag: "wx" }); files[name] = { sha256: sha(bytes), bytes: typeof bytes === "string" ? Buffer.byteLength(bytes) : bytes.byteLength }; };
await save("ownership.json.source", ownBytes);
await save("ready.json.source",readyBytes);
await save("startup-receipt.json.source",startupBytes);
await save("version-receipt.json.source",versionBytes);
await save("referenced-template-inputs.json.source",templateBytes);
await save("login-otp.html.source",templateFileBytes);
await save("source-git-proofs.json",json(sourceGitProofs));
for(const [name,bytes]of Object.entries(prerequisiteStreams))await save("prerequisite-"+name,bytes);
await save("config.toml.source", configBytes);
await save("postgres-version.source", pgVersion);
await save("executed-harness.source", await readFile(import.meta.filename));
for (const [i, [path, bytes]] of [...frozen].entries()) await save("source-" + String(i).padStart(3, "0") + ".bin", bytes);
const commands: Record<string, unknown>[] = [];
const run = async (name: string, argv: string[], stdin?: string) => {
  const proc = Bun.spawn(argv, { cwd: root, stdin: stdin === undefined ? "ignore" : "pipe", stdout: "pipe", stderr: "pipe" });
  if (stdin !== undefined) { proc.stdin!.write(stdin); proc.stdin!.end(); }
  const [stdout, stderr, nativeExit] = await Promise.all([new Response(proc.stdout).arrayBuffer(), new Response(proc.stderr).arrayBuffer(), proc.exited]);
  const outBytes = new Uint8Array(stdout), errBytes = new Uint8Array(stderr);
  await save(name + ".stdout", outBytes); await save(name + ".stderr", errBytes);
  commands.push({ name, argv, pid: proc.pid, nativeExit, stdoutSha256: sha(outBytes), stderrSha256: sha(errBytes), stdinSha256: stdin === undefined ? null : sha(stdin) });
  assert(nativeExit === 0, "Diagnostic subprocess failed: " + name);
  return Buffer.from(outBytes).toString("utf8");
};
const inspectFormat = '{"id":{{json .Id}},"name":{{json .Name}},"imageId":{{json .Image}},"imageName":{{json .Config.Image}},"running":{{json .State.Running}},"ports":{{json .NetworkSettings.Ports}},"mounts":{{json .Mounts}}}';
const dockerBefore: Record<string, unknown> = {};
for (const kind of ["db", "auth"]) {
  const pin = own.containers?.[kind];
  assert(pin?.name === "supabase_" + kind + "_" + projectId && /^sha256:[a-f0-9]{64}$/.test(pin.imageId) && /^[a-f0-9]{64}$/.test(pin.id), "Exact new container/image identity required: " + kind);
  const actual = JSON.parse(await run("identity-" + kind, ["docker", "inspect", "--type", "container", "--format", inspectFormat, pin.name]));
  assert(actual.id === pin.id && actual.name === "/" + pin.name && actual.imageId === pin.imageId && actual.imageName === pin.imageName && actual.running === true, "Owned running container differs: " + kind);
  assert(kind === "db" ? /(?:^|\/)supabase\/postgres:17\.11\.0\.004$/.test(actual.imageName) : /(?:^|\/)supabase\/gotrue:v2\.197\.0$/.test(actual.imageName), "Observed-CI managed image tag differs: " + kind);
  if (kind === "db") assert(actual.ports?.["5432/tcp"]?.length && actual.ports["5432/tcp"].every((p: { HostPort: string }) => p.HostPort === "61322"), "New database publication differs");
  dockerBefore[kind] = actual;
}
const captureQueries = { catalog: catalogQuery, functions: functionsQuery, targets: targetQuery, auth: authQuery, native: nativeQuery, indexes: indexDetailsQuery, shape: shapeQuery };
const runtimeQuery = "select jsonb_build_object('serverVersionNum',current_setting('server_version_num'),'version',version(),'currentUser',current_user,'database',current_database(),'databaseOwner',(select pg_get_userbyid(datdba) from pg_database where datname=current_database()))";
const ledgerQuery = "select coalesce(jsonb_agg(jsonb_build_object('version',version,'name',name,'statements',statements) order by version),'[]'::jsonb) from supabase_migrations.schema_migrations";
const sequencesQuery = "select coalesce(jsonb_agg(to_jsonb(s) order by schemaname,sequencename),'[]'::jsonb) from pg_sequences s where schemaname !~ '^pg_'";
const captureQuery = async (stage: string, key: string, query: string) => {
  // Original query bytes are preserved; transaction/psql transport are recorded separately.
  await save(stage + "-" + key + ".sql.source", query);
  const input = "BEGIN READ ONLY;\nSET LOCAL search_path = '';\n" + query + ";\nROLLBACK;\n";
  const raw = await run(stage + "-" + key, ["docker", "exec", "-i", own.containers.db.name, "psql", "-X", "-q", "-A", "-t", "-v", "ON_ERROR_STOP=1", "-U", "postgres", "-d", "postgres"], input);
  return JSON.parse(raw.trim());
};
let db: SQL | undefined, acceptedTwice = false;
const receipt: Record<string, unknown> = { receiptVersion: 1, receiptType: "task8-cold-fix-1-admission-rollback", authority: own.authority, ownerNonce: own.ownerNonce, projectId, out, startedAt: new Date().toISOString(), productionApplied: false, deployment: false, operationalEnablement: false, sharedEndpointsQueried: false, native19: "NOT_RUN", sourceChanges: false, commands, files, dockerBefore, fixtureScope, frozenSources: Object.fromEntries([...frozen].map(([path,b]) => [path, {sha256:sha(b),rawBytes:b.byteLength}])) };
try {
  const runtime = await captureQuery("before", "runtime", runtimeQuery);
  assert(runtime.serverVersionNum === "170011" && runtime.currentUser === "postgres" && runtime.database === "postgres" && runtime.databaseOwner === "postgres", "Owned native runtime/owner differs");
  receipt.runtime = runtime;
  const ledger = await captureQuery("before", "ledger", ledgerQuery);
  assert(ledger.length === 186 && isDeepStrictEqual(ledger.map((p: {version: string}) => p.version), expectedPredecessors.map(p => p.split("/").at(-1)!.slice(0,14))), "Actual database predecessor ledger differs");
  db = new SQL(expectedUrl, { max: 1 });
  const [connected] = await db.unsafe(runtimeQuery);
  assert(isDeepStrictEqual(connected.jsonb_build_object, runtime), "Loopback connection is not the owned inspected runtime");
  // Proxy records the unchanged scanner's query bytes/results; returns original rows.
  let scanSequence = 0;
  const traced = (sql: SQL): SQL => new Proxy(sql, { get(target, key) {
    if (key === "unsafe") return async (...args: Parameters<SQL["unsafe"]>) => {
      const name = "scanner-" + String(scanSequence++).padStart(2,"0");
      await save(name + ".sql.source", args[0]);
      try { const rows = await target.unsafe(...args); await save(name + ".rows.json", json(rows)); await save(name + ".call.json", json({resolved:true,querySha256:sha(args[0]),transformApplied:false})); return rows; }
      catch (e) { await save(name + ".call.json", json({resolved:false,message:(e as Error).message,errno:(e as {errno?:string}).errno})); throw e; }
    };
    if (key === "begin") return (fn: (tx: SQL) => Promise<unknown>) => target.begin(tx => fn(traced(tx)));
    const value = Reflect.get(target,key,target); return typeof value === "function" ? value.bind(target) : value;
  } });
  await assertSafeFixtureTables(traced(db), fixtureScope);
  receipt.fullSevenTableScannerPassed = true;
  const empty = async (stage: string) => {
    const facts = [];
    for (const name of fixtureScope) {
      const table = name.includes(".") ? name : "public." + name;
      const rows = await db!.unsafe("select exists(select 1 from " + table + ") populated");
      facts.push({table,populated:rows[0].populated}); assert(rows[0].populated === false, "Fresh seven-table fixture scope is populated: " + table);
    }
    await save(stage + "-zero-rows.json", json(facts)); return facts;
  };
  receipt.zeroRowsBefore = await empty("before");
  const capture = async (stage: string) => {
    const result: Record<string, unknown> = {};
    for (const [key,query] of Object.entries(captureQueries)) result[key] = await captureQuery(stage,key,query);
    result.ledger = await captureQuery(stage,"ledger-full",ledgerQuery);
    result.sequences = await captureQuery(stage,"sequences",sequencesQuery);
    await save(stage + "-profile.json", json(result)); return result;
  };
  const before = await capture("before");
  receipt.profileBeforeSha256 = files["before-profile.json"].sha256;
  const application = Buffer.from(frozen.get(task8)!).toString("utf8");
  // Exact Task8 transport: one SET LOCAL and one DO. No outer transaction wrappers.
  const transport = application.replace(/\$migration\$[\s\S]*?\$migration\$/g,"DO_BODY").replace(/--[^\n]*/g,"");
  assert(!/\b(?:BEGIN|COMMIT|ROLLBACK|END)\b/i.test(transport),"Outer transaction control refused");
  const forced = Error("Task8 successful apply twice deliberately rolled back");
  try {
    await db.begin(async tx => {
      await tx.unsafe("set local role postgres");
      await tx.unsafe(application);
      const first = (await tx.unsafe(targetQuery))[0].value;
      const originalRegistration = (before.targets as {name:string}[]).find(t=>t.name==="create_volunteer_registration_idempotent");
      assert(isDeepStrictEqual(first.find((t:{name:string})=>t.name==="create_volunteer_registration_idempotent"),originalRegistration),"Registration tuple/body/ACL changed");
      await tx.unsafe(application);
      const second = (await tx.unsafe(targetQuery))[0].value;
      assert(isDeepStrictEqual(first,second),"Second application changed targets");
      await save("apply-twice-targets.json",json({first,second,registrationPreserved:true}));
      throw forced;
    });
  } catch (e) {
    const error = { name:(e as Error).name, message:(e as Error).message, errno:(e as {errno?:string}).errno ?? null, acceptedTwiceAndRolledBack:e===forced };
    await save("actual-admission-result.json",json(error));
    acceptedTwice=e===forced; // Historical variable name: this regression now requires acceptance.
    receipt.admission=error;
  }

  assert(acceptedTwice,"Apply twice must succeed before refusal or synthetic business checks");
  const registrationSignature = "uuid,uuid,text,integer,text,text,text,text,text,integer,integer,text,text,text,text,timestamp with time zone,boolean,boolean";
  const refusalCases = [
    ["table grant option","grant select on public.supporter to authenticated with grant option"],
    ["column grant option","grant update(name) on public.supporter to authenticated with grant option"],
    ["RLS","alter table public.volunteer_activity disable row level security"],
    ["column shape","alter table public.supporter add column task8_unknown text"],
    ["constraint","alter table public.supporter add constraint task8_unknown check(name <> 'unknown')"],
    ["index addition","create index task8_unknown on public.supporter(name)"],
    ["trigger","alter table public.supporter disable trigger bump_supporter_edit_version"],
    ["policy","create policy task8_unknown on public.supporter for select to anon using(true)"],
    ["helper configuration","alter function private.bump_supporter_edit_version() set search_path='public'"],
    ["managed Auth column ACL","grant select(email) on auth.users to anon"],
    ["native FK","alter table public.volunteer_registration alter constraint volunteer_registration_activity_id_fkey deferrable initially deferred"],
    ["index flags","alter table public.supporter cluster on supporter_pkey"],
    ["relation shape","create rule task8_unknown as on delete to public.supporter do instead nothing"],
    ["schema privilege","grant create on schema public to anon"],
    ["default privilege","alter default privileges for role postgres in schema public revoke execute on functions from anon"],
    ["role membership","grant authenticated to anon"],
    ["clone overload after registration absent",`drop function public.create_volunteer_registration_idempotent(${registrationSignature}); create function public.clone_volunteer_activity_with_audit(uuid) returns uuid language sql as 'select $1'`],
    ["registration overload after clone absent","drop function public.clone_volunteer_activity_with_audit(uuid,uuid,timestamp with time zone); create function public.create_volunteer_registration_idempotent(uuid) returns uuid language sql as 'select $1'"],
    ["unknown target body","create or replace function public.clone_volunteer_activity_with_audit(p_source_activity_id uuid,p_actor_user_id uuid,p_starts_at timestamp with time zone default null) returns uuid language plpgsql security definer set search_path='' as 'begin return p_source_activity_id; end'"],
    ["crossed modern supporter with cold helpers","revoke insert(id,name,email,phone,language,tags,source,deleted_at,created_at,updated_at,edit_version),update(id,name,email,phone,language,tags,source,deleted_at,created_at,updated_at,edit_version) on public.supporter from authenticated; grant insert,update on public.supporter to authenticated"],
  ];
  const refusals:unknown[]=[];
  for (const [index,[name,setup]] of refusalCases.entries()) {
    let result:Record<string,unknown>={name,setup};
    try {
      await db.begin(async tx=>{
        await tx.unsafe("set local role postgres; set local search_path=''");
        await tx.unsafe(setup); // Setup errors never count as a passing refusal.
        const targetBefore=(await tx.unsafe(targetQuery))[0].value;
        await tx.unsafe("savepoint task8_application");
        try {await tx.unsafe(application);throw Error("Mutation unexpectedly admitted: "+name);}
        catch(e) {
          const error={message:(e as Error).message,errno:(e as {errno?:string}).errno??null};
          await tx.unsafe("rollback to savepoint task8_application; release savepoint task8_application");
          assert(error.errno==="55000","Wrong refusal/setup failure for "+name+": "+error.message);
          if(name.startsWith("crossed"))assert(error.message.includes("correlated profile differs"),"Crossed tuple refused by an unrelated per-facet check");
          if(name.includes("overload"))assert(error.message.includes("unexpected overload"),"Overload refused by an unrelated check");
          const targetAfter=(await tx.unsafe(targetQuery))[0].value;
          assert(isDeepStrictEqual(targetBefore,targetAfter),"Refusal changed target body/ACL/overload tuples");
          result={...result,...error,setupSucceeded:true,targetPreflightPreserved:true};
        }
        throw forced;
      });
    }catch(e){if(e!==forced)throw e;}
    refusals.push(result);await save("refusal-"+String(index).padStart(2,"0")+".json",json(result));
  }

  // Reserved-role mutation needs the isolated container's local administrative user.
  // The application still runs as postgres, and ON_ERROR_STOP closes the failed
  // transaction. No COMMIT is present or reached in this transport.
  const roleInput="\\set VERBOSITY verbose\nBEGIN;\nALTER ROLE authenticated NOINHERIT;\nSET LOCAL ROLE postgres;\n"+application+"\nROLLBACK;\n";
  await save("refusal-role-attributes.sql.transport",roleInput);
  const roleArgv=["docker","exec","-i",own.containers.db.name,"psql","-X","-q","-A","-t","-v","ON_ERROR_STOP=1","-U","supabase_admin","-d","postgres"];
  const roleProc=Bun.spawn(roleArgv,{cwd:root,stdin:"pipe",stdout:"pipe",stderr:"pipe"});
  roleProc.stdin.write(roleInput);roleProc.stdin.end();
  const [roleOut,roleErr,roleExit]=await Promise.all([new Response(roleProc.stdout).arrayBuffer(),new Response(roleProc.stderr).arrayBuffer(),roleProc.exited]);
  await save("refusal-role-attributes.stdout",new Uint8Array(roleOut));await save("refusal-role-attributes.stderr",new Uint8Array(roleErr));
  const roleMessage=Buffer.from(roleErr).toString("utf8");
  commands.push({name:"refusal-role-attributes",argv:roleArgv,nativeExit:roleExit,stdinSha256:sha(roleInput),stdoutSha256:sha(new Uint8Array(roleOut)),stderrSha256:sha(new Uint8Array(roleErr))});
  assert(roleExit===3&&roleMessage.includes("55000")&&roleMessage.includes("R01 volunteer roles differs")&&!roleMessage.includes("42501"),"Reserved-role mutation setup/expected application refusal absent");
  refusals.push({name:"role attributes",setupSucceeded:true,applicationUser:"postgres",setupUser:"supabase_admin",errno:"55000",nativeExit:roleExit,rollback:"connection terminated on expected error; no COMMIT"});

  receipt.actualSqlRefusals=refusals;
  receipt.actualSqlRefusalCasesPassed=true;
  const ids={actor:crypto.randomUUID(),activity:crypto.randomUUID(),supporter:crypto.randomUUID(),token:crypto.randomUUID().replaceAll("-","").repeat(2)};
  const stateQuery="select jsonb_build_object('activity',(select jsonb_agg(to_jsonb(t) order by id) from public.volunteer_activity t),'registration',(select jsonb_agg(to_jsonb(t) order by id) from public.volunteer_registration t),'audit',(select jsonb_agg(to_jsonb(t) order by id) from public.audit_log t),'consent',(select jsonb_agg(to_jsonb(t) order by id) from public.supporter_consent_intent t)) value";
  const business:Record<string,unknown>={};
  try {
    await db.begin(async tx=>{
      await tx.unsafe(application);
      await tx`insert into auth.users(id,email,email_confirmed_at) values(${ids.actor}::uuid,${ids.actor+"@example.invalid"},now())`;
      await tx`insert into public.admin_user(auth_user_id,email,role,status) values(${ids.actor}::uuid,${ids.actor+"@example.invalid"},'staff','active')`;
      await tx`insert into public.supporter(id,name,email,source) values(${ids.supporter}::uuid,'Synthetic volunteer',${ids.supporter+"@example.invalid"},'volunteer_registration_form')`;
      await tx`insert into public.volunteer_activity(id,type,title,description,starts_at,ends_at,location,capacity,status,auto_approve) values(${ids.activity}::uuid,'cleaning_day','Synthetic Task8 activity','Synthetic description','2000-01-01T02:00:00Z','2000-01-01T05:00:00Z','Owned rollback fixture',1,'published',true)`;
      const asRole = async <T>(role:string,run:()=>Promise<T>)=>{
        assert(["service_role","anon","authenticated"].includes(role),"Synthetic role refused");
        await tx.unsafe("savepoint task8_role");
        try {await tx.unsafe("set local role "+role);const value=await run();await tx.unsafe("set local role postgres; release savepoint task8_role");return value;}
        catch(e){await tx.unsafe("rollback to savepoint task8_role; release savepoint task8_role");throw e;}
      };
      const register=()=>asRole("service_role",async()=>{
        const [row]=await tx`select public.create_volunteer_registration_idempotent(${ids.activity}::uuid,${ids.supporter}::uuid,'individual',1,'Synthetic volunteer',${ids.supporter+"@example.invalid"},'91234567','zh-HK',null::text,21,null::integer,null::text,null::text,null::text,${ids.token},'2099-02-01T00:00:00Z'::timestamptz,true,true) value`;
        return row.value as {created:boolean;registration:{id:string}};
      });
      const clone=(actor=ids.actor,role="service_role")=>asRole(role,async()=>{
        const [row]=await tx`select public.clone_volunteer_activity_with_audit(${ids.activity}::uuid,${actor}::uuid,null::timestamptz) id`;return row.id;
      });
      const first=await register(),retry=await register();
      assert(first.created===true&&retry.created===false&&first.registration.id===retry.registration.id,"Registration retry lost idempotency");
      const consent=(await tx`select count(*)::integer count from public.supporter_consent_intent where submission_id=${first.registration.id}::uuid`)[0].count;
      assert(consent===2,"Registration consent facts differ");
      const cloneId=await clone(),audits=(await tx`select count(*)::integer count from public.audit_log where entity_id=${cloneId} and action='volunteer_activity.clone'`)[0].count;
      assert(audits===1,"Clone did not create exactly one atomic audit");
      const expectRefusal=async(name:string,code:string,run:()=>Promise<unknown>)=>{
        const beforeState=(await tx.unsafe(stateQuery))[0].value;
        let actual:string|null=null;try{await run();}catch(e){actual=(e as {errno?:string}).errno??null;}
        assert(actual===code,"Wrong synthetic refusal: "+name);
        assert(isDeepStrictEqual(beforeState,(await tx.unsafe(stateQuery))[0].value),"Synthetic refusal changed domain rows: "+name);
        business[name]={errno:actual,domainRowsPreserved:true};
      };
      for(const role of ["anon","authenticated"])await expectRefusal(role+" cannot clone","42501",()=>clone(ids.actor,role));
      await expectRefusal("missing actor","42501",()=>clone(crypto.randomUUID()));
      await tx`update auth.users set banned_until='2099-01-01T00:00:00Z' where id=${ids.actor}::uuid`;
      await expectRefusal("banned actor","42501",()=>clone());
      await tx`update auth.users set banned_until=null,email_confirmed_at=null where id=${ids.actor}::uuid`;
      await expectRefusal("unconfirmed actor","42501",()=>clone());
      await tx`update auth.users set email_confirmed_at=now() where id=${ids.actor}::uuid`;
      await tx`update public.admin_user set role='treasurer' where auth_user_id=${ids.actor}::uuid`;
      await expectRefusal("non-staff actor","42501",()=>clone());
      await tx`update public.admin_user set role='staff' where auth_user_id=${ids.actor}::uuid`;
      await tx`create function pg_temp.task8_fail_audit() returns trigger language plpgsql as 'begin raise exception ''injected_task8_audit_failure''; end'`;
      await tx`create trigger task8_fail_audit after insert on public.audit_log for each row when(new.action='volunteer_activity.clone') execute function pg_temp.task8_fail_audit()`;
      await expectRefusal("audit failure","P0001",()=>clone());
      business.registrationIdempotent=true;business.consentFacts=consent;business.cloneAuditCount=audits;
      await save("synthetic-business.json",json(business));
      throw forced;
    });
  }catch(e){if(e!==forced)throw e;}
  receipt.syntheticBusinessRollbackPassed=true;

  const after = await capture("after");
  receipt.zeroRowsAfter = await empty("after");
  receipt.completeProfileRollbackPreserved = isDeepStrictEqual(before,after);
  receipt.actualAdmissionAcceptedTwice = acceptedTwice;
  assert(receipt.completeProfileRollbackPreserved === true && acceptedTwice, "Expected Task8 apply-twice acceptance/complete rollback preservation absent");
} catch (e) {
  receipt.error = {name:(e as Error).name,message:(e as Error).message,errno:(e as {errno?:string}).errno ?? null};
  process.exitCode = 1;
} finally {
  if (db) await db.close();
  receipt.frozenInputsPreserved = (await Promise.all([...frozen].map(async ([path,b]) => Buffer.from(b).equals(await readFile(resolve(root,path)))))).every(Boolean);
  receipt.ownershipAndConfigPreserved = Buffer.from(ownBytes).equals(await readFile(ownershipPath)) && Buffer.from(configBytes).equals(await readFile(config)) && Buffer.from(readyBytes).equals(await readFile(readyPath)) && Buffer.from(startupBytes).equals(await readFile(startupPath)) && Buffer.from(versionBytes).equals(await readFile(versionReceiptPath)) && Buffer.from(pgVersion).equals(await readFile(pgVersionPath)) && Buffer.from(templateBytes).equals(await readFile(templateReceiptPath)) && Buffer.from(templateFileBytes).equals(await readFile(resolve(project,templatePin.file)));
  try {
    const dockerAfter: Record<string, unknown> = {};
    for (const kind of ["db","auth"]) dockerAfter[kind] = JSON.parse(await run("after-identity-" + kind,["docker","inspect","--type","container","--format",inspectFormat,own.containers[kind].name]));
    receipt.dockerIdentitiesPreserved = isDeepStrictEqual(dockerBefore,dockerAfter); receipt.dockerAfter = dockerAfter;
  } catch (e) { receipt.finalIdentityError = (e as Error).message; receipt.dockerIdentitiesPreserved = false; }
  const requiredFinalFlags = ["fullSevenTableScannerPassed","actualAdmissionAcceptedTwice","completeProfileRollbackPreserved","frozenInputsPreserved","ownershipAndConfigPreserved","dockerIdentitiesPreserved","actualSqlRefusalCasesPassed","syntheticBusinessRollbackPassed"];
  receipt.requiredFinalFlags = requiredFinalFlags;
  receipt.failedFinalFlags = requiredFinalFlags.filter(k => receipt[k] !== true);
  receipt.completedAt = new Date().toISOString();
  receipt.cleanup = "No lifecycle mutation; root owns later normal cleanup of this unique project";
  if ((receipt.failedFinalFlags as string[]).length || receipt.error) process.exitCode = 1;
  await writeFile(resolve(out,"receipt.json"), json(receipt), {flag:"wx"});
  console.log(json({out,admissionAcceptedTwice:acceptedTwice,failedFinalFlags:receipt.failedFinalFlags,error:receipt.error??null,native19:"NOT_RUN"}));
}
