import hashlib,json,os,pathlib,subprocess,sys,datetime
sys.stdout.reconfigure(encoding="utf-8")
phase=sys.argv[1];assert phase in ("red","green")
r=pathlib.Path.cwd();c=r/".superpowers/sdd/sequential-merge-20261006";out=c/("task8-ci-contract-"+phase+"-201-20261007")
assert not out.exists();out.mkdir()
environment={k:os.environ[k] for k in ("SystemRoot","WINDIR","PATH","TEMP","TMP","USERPROFILE","HOME") if k in os.environ}
for pre in ("","LOCAL_"):
 environment.update({pre+"SUPABASE_URL":"http://127.0.0.1:59999",pre+"SUPABASE_ANON_KEY":"ci-placeholder-anon-key",pre+"SUPABASE_SERVICE_ROLE_KEY":"ci-placeholder-service-role-key"})
argv=[r"C:/Users/laich/.bun/bin/bun.exe","--no-env-file","test","--timeout","15000","src/lib/volunteers/atomicForwardFixtureGuard.test.ts"]
before={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in (".github/workflows/ci.yml","src/lib/volunteers/atomicForwardFixtureGuard.test.ts","src/lib/volunteers/atomicForwardFixtureGuard.ts")}
q=subprocess.run(argv,cwd=r,env=environment,capture_output=True,timeout=45)
streams=[]
for n,b in (("stdout",q.stdout),("stderr",q.stderr)):
 (out/n).write_bytes(b);streams.append({"file":n,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
assert before=={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in before}
expected=1 if phase=="red" else 0
receipt={"phase":phase,"argv":argv,"cwd":str(r),"nativeExit":q.returncode,"expectedNativeExit":expected,"atUtc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourceBeforeAfter":before,"environment":environment,"productionProviderFixtureOptins":"OMITTED","databaseOperations":False,"native19":"NOT_RUN","streams":streams}
(out/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
assert q.returncode==expected
if phase=="red":assert b"(fail) CI requires Task8 immediately after fresh startup" in q.stderr
else:assert b"7 pass" in q.stderr and b"0 fail" in q.stderr
print(json.dumps({"phase":phase,"nativeExit":q.returncode,"receipt":str(out/"receipt.json"),"streams":streams}))

